import CONFIGURACIÓN

def altura_pct(porcentaje):
    return (CONFIGURACIÓN.ALTO / 100) * porcentaje

def ancho_pct(porcentaje):
    return (CONFIGURACIÓN.ANCHO / 100) * porcentaje